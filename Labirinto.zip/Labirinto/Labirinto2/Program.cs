﻿using System;
using System.Globalization;

namespace Labirinto
{
    class Program
    {
        #region Propriedades, variaveis e constantes

        #region Constantes
        private const Char cParede = '#';
        private const Char cCaminho = ' ';
        private const Char cFim = 'F';
        private const Char cJogador = '^';
        private const Int16 cColuna = 8;
        private const Int16 cLinha = 16;
        #endregion

        #region Propriedades
        private static Int16 PosLinha { get; set; }
        private static Int16 PosColuna { get; set; }
        private static Int16 Vidas { get; set; }
        private static Int16 Passos { get; set; }
        private static bool JogadorPerdido { get; set; }
        #endregion

        private static string informacoesExtras
        {
            get
            {
                return "Passos: " + Passos + " Vidas: " + Vidas;
            }
        }

        private static char[,] labirinto =
        {
            {cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede },
            {cParede, cParede, cParede, cParede, cParede, cParede, cParede, cCaminho, cCaminho, cCaminho, cParede, cParede, cParede, cCaminho, cParede, cParede },
            {cParede, cParede, cParede, cParede, cCaminho, cCaminho, cParede, cCaminho, cParede, cCaminho, cParede, cParede, cCaminho, cCaminho, cCaminho, cParede },
            {cParede, cParede, cCaminho, cCaminho, cCaminho, cCaminho, cParede, cCaminho, cParede, cCaminho, cParede, cParede, cCaminho, cParede, cParede, cParede },
            {cParede, cCaminho, cCaminho, cParede, cParede, cCaminho, cParede, cCaminho, cParede, cCaminho, cCaminho, cParede, cCaminho, cParede, cCaminho, cFim },
            {cParede, cCaminho, cParede, cParede, cParede, cCaminho, cParede, cCaminho, cParede, cParede, cCaminho, cCaminho, cCaminho, cParede, cCaminho, cParede },
            {cParede, cJogador, cParede, cParede, cParede, cCaminho, cCaminho, cCaminho, cParede, cParede, cParede, cParede, cCaminho, cCaminho, cCaminho, cParede },
            {cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede, cParede }
        };

        #endregion

        #region Métodos
        static void Main()
        {
            IniciarVariaveis();
            GameLooping();
        }

        private static string EscreverTitulo()
        {
            return "Labirinto - " + informacoesExtras;
        }

        private static void IniciarVariaveis()
        {
            Console.CursorVisible = false;
            labirinto[PosLinha, PosColuna] = cCaminho;
            PosLinha = 6;
            PosColuna = 1;
            labirinto[PosLinha, PosColuna] = cJogador;
            Vidas = 3;
            Passos = 0;
            JogadorPerdido = true;
            Console.Title = EscreverTitulo();
        }

        private static void GameLooping()
        {
            while (true)
            {
                while (JogadorPerdido && Vidas > 0)
                {
                    Console.Clear();
                    MontarLabirinto();
                    Input();
                    Console.Title = EscreverTitulo();
                }

                Console.Clear();
                Console.WriteLine(DescreverFinal());

                if (Console.ReadKey(false).KeyChar.ToString(CultureInfo.InvariantCulture).ToUpper().Equals("N"))
                    return;

                IniciarVariaveis();
            }

        }

        private static void MontarLabirinto()
        {
            for (Int16 i = 0; i < cColuna; i++)
            {
                for (Int16 j = 0; j < cLinha; j++)
                    Console.Write(labirinto[i, j]);

                Console.WriteLine();
            }
            Console.WriteLine("W - SOBE | A - ESQUERDA | S - DESCE | D - DIREITA \n" + informacoesExtras);
        }

        private static void Input()
        {
            switch (Console.ReadKey(false).KeyChar.ToString(CultureInfo.InvariantCulture).ToUpper())
            {
                case "W":
                    Andar((short)(PosLinha - 1), PosColuna);
                    break;
                case "A":
                    Andar(PosLinha, (short)(PosColuna - 1));
                    break;
                case "S":
                    Andar((short)(PosLinha + 1), PosColuna);
                    break;
                case "D":
                    Andar(PosLinha, (short)(PosColuna + 1));
                    break;
            }
        }

        private static void Andar(Int16 pLinha, Int16 pColuna)
        {
            ++Passos;


            if (labirinto[pLinha, pColuna].Equals(cCaminho))
            {
                LimparCaminhoAtual();
                labirinto[pLinha, pColuna] = cJogador;
                PosLinha = pLinha;
                PosColuna = pColuna;
            }
            else if (labirinto[pLinha, pColuna].Equals(cFim))
                JogadorPerdido = false;
            else
            {
                --Vidas;
                Console.Beep();
            }
        }

        private static void LimparCaminhoAtual()
        {
            labirinto[PosLinha, PosColuna] = cCaminho;
        }

        private static string DescreverFinal()
        {
            return (JogadorPerdido
                ? "\rVocê falhou!"
                : "\rParabéns você conseguiu!") + "\nPara recomeçar o jogo tecle ENTER." + "\nPara sair tecle N.";

        }
        #endregion
    }
}